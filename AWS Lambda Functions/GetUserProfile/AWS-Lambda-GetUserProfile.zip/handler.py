import os
import pymysql

# Configuration Values
endpoint = os.environ['RDS_ENDPOINT']
username = os.environ['RDS_USERNAME']
password = os.environ['RDS_PASSWORD']
database_name = os.environ['RDS_DATABASE']

# Connection
connection = pymysql.connect(host=endpoint, user=username, passwd=password, db=database_name)

def getUserProfile_handler(event, context):

    returnVal = {
        "statusCode": 200
    }

    username = event['username']

    sql_query = "SELECT * FROM Users WHERE username = (%s)"

    try:
        cursor = connection.cursor()
        cursor.execute(sql_query, (username))
        tuple = cursor.fetchone()

        if tuple is not None:
            email = tuple[1]
            name = tuple[2]
            address = tuple[3]
            birthdate = tuple[4]

            returnVal['username'] = username
            returnVal['email'] = email

            if name is not None:
                returnVal['name'] = name
            else:
                returnVal['name'] = ""
            if address is not None: 
                returnVal['address'] = address
            else:
                returnVal['address'] = ""
            if birthdate is not None:
                returnVal['birthdate'] = address
            else:
                returnVal['birthdate'] = ""

        else:
            returnVal['message'] = "Username '" + username + "' does not exist in the database"

        return returnVal

    except:
        
        returnVal['statusCode'] = 503
        returnVal['message'] = "Unable to connect to the database"
        return returnVal